-- ms1.hs

module MilliSecond1 where

valueIfSame :: (Num a, Eq a) => a -> a -> a
valueIfSame x y = (boolToInt (x == y)) * x
    where
        boolToInt b
            | b == True = 1
            | otherwise = 0

nextPair :: (Num a, Eq a) => [a] -> Int -> a
nextPair code index = valueIfSame (code !! index) (code !! (index `mod` length code))

arrayToPairs x = zip x [0..]

