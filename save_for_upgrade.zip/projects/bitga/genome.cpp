#include <cstdint>
#include <ostream>

#include "genome.h"
#include "PRNG.h"

template<int FIELD_WIDTH>
ostream& operator << (ostream& os, const Genome<FIELD_WIDTH>& obj)
{
    int last_index = obj.arrLength - 1;
    if(!obj.uses_all)
    {
        uint64_t to_print = obj.data[last_index];
        for(int i = obj.remainder-1; i >= 0; i--)
        {
            const uint64_t one = 1;
            os << ((to_print >> i) & one);
        }
    }

    for(int i = last_index - !obj.uses_all; i >= 0; i--)
    {
        uint64_t to_print = obj.data[i];
        for(int j = obj.int_width-1; j >= 0; j--)
        {
            os << ((to_print >> j) & 1);
        }
    }
    return os;
}

template<int FIELD_WIDTH>
inline Genome<FIELD_WIDTH> operator<<(Genome<FIELD_WIDTH> lhs, const int &rhs)
{
    return lhs <<= rhs;
}
