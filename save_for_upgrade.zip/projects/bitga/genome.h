#ifndef GENOME_H
#define GENOME_H

#include <cstdint>
#include <array>
#include <ostream>
#include <algorithm>

#include "PRNG.h"

template<int FIELD_WIDTH>
class Genome
{
public:
    Genome() : data({}) {}

    template<unsigned long len>
    Genome(std::array<uint64_t, len> new_data) : data(new_data) {}

    Genome(uint64_t new_data)
    {
        data = {new_data};
    }

    void randomise(PRNG &rng)
    {
        for(uint64_t &element : data)
        {
            element = rng.getRandom_uint64();
        }
        if(!uses_all)
        {
            data.back() >>= unused;
        }
    }

    Genome<FIELD_WIDTH> operator <<=(const int &rhs)
    {
        if(rhs == 0) return *this;
        if(rhs < int_width)
        {
            uint64_t carry = 0;
            for(uint64_t &element : data)
            {
                uint64_t temp = element;
                element <<= rhs;
                element ^= carry;
                carry = temp >> (int_width - rhs);
            }
        }
        else
        {
            *this <<= rhs % int_width;
            int jumps = rhs / int_width;
            int target = last_index;
            for(int source = last_index - jumps; source >= 0; source--)
            {
                data[target] = data[source];
                target--;
            }
            for(int i = 0; i < jumps; i++)
            {
                data[i] = 0;
            }
        }
        if(!uses_all)
        {
            data.back() &= end_mask;
        }
        return *this;
    }

    Genome<FIELD_WIDTH> operator >>=(const int &rhs)
    {
        if(rhs == 0) return *this;
        if(rhs < int_width)
        {
            uint64_t carry = 0;
            for(int i = last_index; i >= 0; i--)
            {
                uint64_t temp = data[i];
                data[i] >>= rhs;
                data[i] ^= carry;
                carry = temp << (int_width - rhs);
            }
        }
        else
        {
            *this >>= rhs % int_width;
            int jumps = rhs / int_width;
            int target = 0;
            for(int source = jumps; source < arrLength; source++)
            {
                data[target] = data[source];
                target++;
            }
            for(int i = last_index; i > last_index - jumps; i--)
            {
                data[i] = 0;
            }
        }
        return *this;
    }

    Genome<FIELD_WIDTH> operator &=(const Genome<FIELD_WIDTH> &rhs)
    {
        for(int i = 0; i < arrLength; i++)
        {
            data[i] &= rhs.data[i];
        }
        return *this;
    }

    Genome<FIELD_WIDTH> operator |=(const Genome<FIELD_WIDTH> &rhs)
    {
        for(int i = 0; i < arrLength; i++)
        {
            data[i] |= rhs.data[i];
        }
        return *this;
    }

    Genome<FIELD_WIDTH> operator ^=(const Genome<FIELD_WIDTH> &rhs)
    {
        for(int i = 0; i < arrLength; i++)
        {
            data[i] ^= rhs.data[i];
        }
        return *this;
    }

    /**
     * It is expected that bitwise not does not modify in place
     * which may not be efficient here. So it has been implemented
     * here as a function to remove any ambigity.
     *
     * To be perfectly clear: this modifies in place.
     */
    void complement()
    {
        for(auto &element : data)
        {
            element = ~element;
        }
        if(!uses_all)
        {
            data.back() &= end_mask;
        }
    }

    void rotl(const int &rhs)
    {
        Genome<FIELD_WIDTH> temp = *this;
        *this <<= rhs;
        temp >>= FIELD_WIDTH - rhs;
        *this ^= temp;
    }

    void rotr(const int &rhs)
    {
        Genome<FIELD_WIDTH> temp = *this;
        *this >>= rhs;
        temp <<= FIELD_WIDTH - rhs;
        *this ^= temp;
    }

    int popcount()
    {
        int total = 0;
        for(auto &element : data)
            total += count_uint64_t(element);
        return total;
    }

    bool parity()
    {
        bool parity = 0;
        for(auto &element : data)
        {
            parity ^= parity64(element);
        }
        return parity;
    }

    void reverse()
    {
        //TODO: create reverse functions for smaller bit lengths
        //TODO: the rotl can be replaced with a left shift and or-ing the
        //      orginal highest with the lowest (saves a right shift)
        for(auto &element : data)
        {
            reverse64(element);
        }
        if(uses_all)
        {
            for(int i = 0; i < arrLength/2; i++)
            {
                std::swap(data[i], data[last_index-i]);
            }
        }
        else
        {
            for(int i = 0; i < (arrLength-1)/2; i++)
            {
                std::swap(data[i], data[last_index-1-i]);
            }
            data.back() >>= unused;
            if(arrLength > 1)
            {
                int temp = remainder;
                rotl(temp);
            }
        }
    }

    template<int F>
    friend std::ostream& operator <<(std::ostream& os, const Genome<F>& obj);
private:
    constexpr static int int_width = sizeof(uint64_t)*8;
    constexpr static int remainder = FIELD_WIDTH % int_width;
    constexpr static int unused = (int_width - remainder) % int_width;
    constexpr static uint64_t end_mask = ~uint64_t(0) >> unused;
    constexpr static bool uses_all = remainder == 0;
    constexpr static int arrLength = FIELD_WIDTH / int_width + !uses_all;
    constexpr static int last_index = arrLength - 1;

    std::array<uint64_t, arrLength> data;

    int count_uint64_t(uint64_t to_count)
    {
    #ifdef __GNUC__
        return __builtin_popcountll(to_count);
    #elif defined(_MSC_VER)
        //TODO: double check this is the rgith one
        return _mm_popcnt_u64(to_count);
    #else
        int pop = 0;
        while(to_count)
        {
            pop++;
            to_count &= to_count-1;
        }
        return pop;
    #endif
    }

    int count_leading_zeros64(const uint64_t &toCount)
    {
    #ifdef __GNUC__
        return __builtin_clzll(toCount) - (sizeof(unsigned long long)*8 - 64);
    #elif defined(_MSC_VER)
        return __lzcnt(toCount);
    #else
        static const int clz64Index[64] = {
            63, 16, 62,  7, 15, 36, 61,  3,
             6, 14, 22, 26, 35, 47, 60,  2,
             9,  5, 28, 11, 13, 21, 42, 19,
            25, 31, 34, 40, 46, 52, 59,  1,
            17,  8, 37,  4, 23, 27, 48, 10,
            29, 12, 43, 20, 32, 41, 53, 18,
            38, 24, 49, 30, 44, 33, 54, 39,
            50, 45, 55, 51, 56, 57, 58,  0
        };
        uint64_t bitset = toCount;
        bitset |= bitset >> 1;
        bitset |= bitset >> 2;
        bitset |= bitset >> 4;
        bitset |= bitset >> 8;
        bitset |= bitset >> 16;
        bitset |= bitset >> 32;
        return clz64Index[(bitset * 0x03f79d71b4cb0a89ULL) >> 58];
    #endif
    }

    bool parity64(uint64_t x)
    {
        //TODO: Add microsoft builtin
    #ifdef __GNUC__
        return __builtin_parityll(x);
    #else
        x ^= x >> 32;
        x ^= x >> 16;
        x ^= x >> 8;
        x ^= x >> 4;
        x &= 0xf;
        return (0x6996 >> x) & 1;
    #endif
    }

    void reverse64(uint64_t &x)
    {
        x = ((x >> 1)  & 0x5555555555555555) | ((x & 0x5555555555555555) << 1);
        x = ((x >> 2)  & 0x3333333333333333) | ((x & 0x3333333333333333) << 2);
        x = ((x >> 4)  & 0x0F0F0F0F0F0F0F0F) | ((x & 0x0F0F0F0F0F0F0F0F) << 4);
        x = ((x >> 8)  & 0x00FF00FF00FF00FF) | ((x & 0x00FF00FF00FF00FF) << 8);
        x = ((x >> 16) & 0x0000FFFF0000FFFF) | ((x & 0x0000FFFF0000FFFF) << 16);
        x = (x >> 32) | (x << 32);
    }

};

template<int FIELD_WIDTH>
std::ostream& operator <<(std::ostream& os, const Genome<FIELD_WIDTH>& obj)
{
    if(!obj.uses_all)
    {
        uint64_t to_print = obj.data[obj.last_index];
        for(int i = obj.remainder-1; i >= 0; i--)
        {
            const uint64_t one = 1;
            os << ((to_print >> i) & one);
        }
    }

    for(int i = obj.last_index - !obj.uses_all; i >= 0; i--)
    {
        uint64_t to_print = obj.data[i];
        for(int j = obj.int_width-1; j >= 0; j--)
        {
            os << ((to_print >> j) & 1);
        }
    }
    return os;
}

template<int FIELD_WIDTH>
inline Genome<FIELD_WIDTH> operator <<(Genome<FIELD_WIDTH> lhs, const int &rhs)
{
    return lhs <<= rhs;
}

template<int FIELD_WIDTH>
inline Genome<FIELD_WIDTH> operator >>(Genome<FIELD_WIDTH> lhs, const int &rhs)
{
    return lhs >>= rhs;
}

template<int FIELD_WIDTH>
inline Genome<FIELD_WIDTH> operator &(Genome<FIELD_WIDTH> lhs, const Genome<FIELD_WIDTH> &rhs)
{
    return lhs &= rhs;
}

template<int FIELD_WIDTH>
inline Genome<FIELD_WIDTH> operator |(Genome<FIELD_WIDTH> lhs, const Genome<FIELD_WIDTH> &rhs)
{
    return lhs |= rhs;
}

template<int FIELD_WIDTH>
inline Genome<FIELD_WIDTH> operator ^(Genome<FIELD_WIDTH> lhs, const Genome<FIELD_WIDTH> &rhs)
{
    return lhs ^= rhs;
}

#endif
