#include <iostream>
#include <cstdint>
#include <cmath>
#include <limits>
#include <bitset>
#include <array>
#include <ostream>

#include "PRNG.h"

using namespace std;

template<int FIELD_WIDTH>
class Genome
{
public:
    Genome() : data({})
    {
        cout << "BEGIN" << endl;
        cout << int_width << endl;
        cout << remainder << endl;
        cout << unused << endl;
        cout << uses_all << endl;
        cout << data.size() << ", " << arrLength << endl;
        cout << data[0] << endl;
    }

    void randomise(PRNG &rng)
    {
        for(uint64_t &element : data)
        {
            element = rng.getRandom_uint64();
        }
        if(!uses_all)
        {
            cout <<data[0] << endl;
            data.back() >>= unused;
        }
    }

    Genome<FIELD_WIDTH> operator<<=(const int &rhs)
    {
        int jumps = rhs / int_width;
        if(jumps == 0)
        {
            uint64_t carry = 0;
            for(uint64_t &element : data)
            {
                uint64_t temp = element;
                element <<= rhs;
                element ^= carry;
                carry = temp >> int_width - rhs;
            }
        }
        else
        {
            *this <<= rhs % int_width;
            int target = data.size() - 1;
            for(int source = data.size() - jumps - 1; source >= 0; source--)
            {
                data[target] = data[source];
                target--;
            }
            for(int i = 0; i < jumps; i++)
            {
                data[i] = 0;
            }
        }
        if(!uses_all)
        {
            data.back() &= end_mask;
        }
        return *this;
    }

    template<int F>
    friend Genome<F> operator<<(Genome<F> lhs, const int &rhs);
    template<int F>
    friend Genome<F> operator>>(Genome<F> lhs, const int &rhs);

    template<int F>
    friend ostream& operator << (ostream& os, const Genome<F>& obj);
private:
    constexpr static int int_width = sizeof(uint64_t)*8;
    constexpr static int remainder = FIELD_WIDTH % int_width;
    constexpr static int unused = (int_width - remainder) % int_width;
    constexpr static uint64_t end_mask = ~uint64_t(0) >> unused;
    constexpr static bool uses_all = remainder == 0;
    constexpr static int arrLength = FIELD_WIDTH / int_width + !uses_all;

    array<uint64_t, arrLength> data;
};

template<int FIELD_WIDTH>
ostream& operator << (ostream& os, const Genome<FIELD_WIDTH>& obj)
{
    int last_index = obj.arrLength - 1;
    if(!obj.uses_all)
    {
        uint64_t to_print = obj.data[last_index];
        for(int i = obj.remainder-1; i >= 0; i--)
        {
            const uint64_t one = 1;
            os << ((to_print >> i) & one);
        }
    }

    if(obj.arrLength > 1)
    {
        for(int i = last_index-1; i >= 0; i--)
        {
            uint64_t to_print = obj.data[i];
            for(int j = obj.int_width-1; j >= 0; j--)
            {
                os << ((to_print >> j) & 1);
            }
        }
    }
}

template<int FIELD_WIDTH>
Genome<FIELD_WIDTH> operator<<(Genome<FIELD_WIDTH> lhs, const int &rhs)
{
    return lhs <<= rhs;
}

template <int GENES>
class GeneticAlgorithm
{
public:
    GeneticAlgorithm(float mutation_rate, float crossover_rate, int population_size)
    {
        this->mutation_rate = floor(log2(1/mutation_rate));
        this->crossover_rate = numeric_limits<uint64_t>::max() * crossover_rate;
    }
private:
    int mutation_rate;
    int crossover_rate;
    Genome<GENES> genes;

    void mutate()
    {
        for(int i = 0; i < mutation_rate; i++)
        {
            Genome<GENES> a; 
            a.randomise();
        }
    }
};

class GenomeBuilder
{
};

int main()
{
    uint64_t a;
    a = 5;
    cout << a << endl;
    //GeneticAlgorithm<90> b (0.01, 0.9, 30);
    PRNG rng;
    Genome<63> c;
    c.randomise(rng);
    cout << c << endl;
    c <<= 10;
    cout << c << endl;

    Genome<90> d;
    d.randomise(rng);
    cout << d << endl;
    d <<= 10;
    cout << d << endl;
}

