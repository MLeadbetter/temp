#include <gtest/gtest.h>

#include "PRNG.h"
#include "genome.h"

#include <array>
#include <string>
#include <sstream>

using namespace std;

namespace {

typedef uint64_t gint;

template <class T>
string get_str(T streamable)
{
    stringstream ss;
    ss << streamable;
    return ss.str();
}

TEST(Genome_printing, prints_one)
{
    array<gint, 1> data = {0b00001};
    Genome<5> genome(data);
    EXPECT_EQ("00001", get_str(genome));
}

TEST(Genome_printing, prints_one_larger)
{
    array<gint, 2> data = {0b0000000000000000000000000000000000000000000000000000000000000000, 0b1};
    Genome<65> genome(data);
    EXPECT_EQ("10000000000000000000000000000000000000000000000000000000000000000", get_str(genome));
}

TEST(Genome_printing, prints_other)
{
    array<gint, 2> data = {0b0000100000000000001000100000100110010001001001000010010010010100, 0b101001};
    Genome<70> genome(data);
    EXPECT_EQ("1010010000100000000000001000100000100110010001001001000010010010010100", get_str(genome));
}

TEST(Genome_printing, print_perfect)
{
    array<gint, 1> data = {
        0b0000000000000000000000000000000000000000000000000000000000000001,
        };
    Genome<64> genome(data);
    EXPECT_EQ("0000000000000000000000000000000000000000000000000000000000000001", get_str(genome));
}

TEST(Genome_printing, print_many)
{
    array<gint, 4> data = {
        0b0000000000000000000000000000000000000000000000000000000000000001,
        0b0000000000000000000000000000000000000000000000000000000000000010,
        0b0000000000000000000000000000000000000000000000000000000000000100,
        0b0000000000000000000000000000000000000000000000000000000000001000
        };
    Genome<64*4> genome(data);
    EXPECT_EQ("0000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000001", get_str(genome));
}

TEST(genome_shift_left, change_nothing)
{
    array<gint, 2> data = {
        0b0000000000000000000000000000000000000000000000000000000000000001,
        0b0000000000000000000000000000000000000000000000000000000000000010
        };
    Genome<2*64> genome(data);
    genome <<= 0;
    EXPECT_EQ("00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000001", get_str(genome));
}

TEST(genome_shift_left, shift_one)
{
    array<gint, 1> data = {0b01};
    Genome<2> genome(data);
    genome <<= 1;
    EXPECT_EQ("10", get_str(genome));
}

TEST(genome_shift_left, shift_gone)
{
    array<gint, 1> data = {0b01};
    Genome<2> genome(data);
    genome <<= 2;
    EXPECT_EQ("00", get_str(genome));
}

TEST(genome_shift_left, shift_boundry)
{
    array<gint, 2> data = {0b1000000000000000000000000000000000000000000000000000000000000000, 0b1};
    Genome<65> genome(data);
    genome <<= 1;
    EXPECT_EQ("10000000000000000000000000000000000000000000000000000000000000000", get_str(genome));
}

TEST(genome_shift_left, shift_without_assignment)
{
    array<gint, 2> data = {0b1000000000000000000000000000000000000000000000000000000000000000, 0b0};
    Genome<65> genome1(data);
    Genome<65> genome2;
    genome2 = genome1 << 1;
    EXPECT_EQ("01000000000000000000000000000000000000000000000000000000000000000", get_str(genome1));
    EXPECT_EQ("10000000000000000000000000000000000000000000000000000000000000000", get_str(genome2));
}

TEST(genome_shift_left, jump)
{
    array<gint, 3> data = {
        0b0000000000000000000000000000000000000000000000000000000000000001,
        0b0000000000000000000000000000000000000000000000000000000000000000,
        0b0};
    Genome<129> genome(data);
    genome <<= 128;
    EXPECT_EQ("100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", get_str(genome));
}

TEST(genome_shift_left, shift_with_jump)
{
    array<gint, 3> data = {
        0b0000000000000000000000000000000000000000000000000000000000000001,
        0b0000000000000000000000000000000000000000000000000000000000000000,
        0b00};
    Genome<130> genome(data);
    genome <<= 129;
    EXPECT_EQ("1000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", get_str(genome));
}

TEST(genome_shift_left, jump_many)
{
    array<gint, 4> data = {
        0b0000000000000000000000000000000000000000000000000000000000000001,
        0b0000000000000000000000000000000000000000000000000000000000000010,
        0b0000000000000000000000000000000000000000000000000000000000000100,
        0b0000000000000000000000000000000000000000000000000000000000001000
        };
    Genome<64*4> genome(data);
    genome <<= 64;
    EXPECT_EQ("0000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000", get_str(genome));
}

TEST(genome_shift_right, change_nothing)
{
    array<gint, 2> data = {
        0b0000000000000000000000000000000000000000000000000000000000000001,
        0b0000000000000000000000000000000000000000000000000000000000000010
        };
    Genome<2*64> genome(data);
    genome >>= 0;
    EXPECT_EQ("00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000001", get_str(genome));
}

TEST(genome_shift_right, shift_one)
{
    array<gint, 1> data = {0b10};
    Genome<2> genome(data);
    genome >>= 1;
    EXPECT_EQ("01", get_str(genome));
}

TEST(genome_shift_right, shift_one_twice)
{
    array<gint, 2> data = {0b10, 0b10};
    Genome<66> genome(data);
    genome >>= 1;
    EXPECT_EQ("010000000000000000000000000000000000000000000000000000000000000001", get_str(genome));
}

TEST(genome_shift_right, shift_one_boundry)
{
    array<gint, 2> data = {
        0b0000000000000000000000000000000000000000000000000000000000000000,
        0b1};
    Genome<65> genome(data);
    genome >>= 1;
    EXPECT_EQ("01000000000000000000000000000000000000000000000000000000000000000", get_str(genome));
}

TEST(genome_shift_right, jump)
{
    array<gint, 3> data = {
        0b0000000000000000000000000000000000000000000000000000000000000000,
        0b0000000000000000000000000000000000000000000000000000000000000000,
        0b1};
    Genome<129> genome(data);
    genome >>= 128;
    EXPECT_EQ("000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", get_str(genome));
}

TEST(genome_shift_right, shift_with_jump)
{
    array<gint, 3> data = {
        0b0000000000000000000000000000000000000000000000000000000000000000,
        0b0000000000000000000000000000000000000000000000000000000000000000,
        0b10};
    Genome<130> genome(data);
    genome >>= 129;
    EXPECT_EQ("0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", get_str(genome));
}

TEST(genome_shift_right, jump_many)
{
    array<gint, 4> data = {
        0b0000000000000000000000000000000000000000000000000000000000000001,
        0b0000000000000000000000000000000000000000000000000000000000000010,
        0b0000000000000000000000000000000000000000000000000000000000000100,
        0b0000000000000000000000000000000000000000000000000000000000001000
        };
    Genome<64*4> genome(data);
    genome >>= 64;
    EXPECT_EQ("0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000010", get_str(genome));
}

TEST(genome_shift_right, shift_without_assignment)
{
    array<gint, 2> data = {0b0000000000000000000000000000000000000000000000000000000000000000, 0b1};
    Genome<65> genome1(data);
    Genome<65> genome2;
    genome2 = genome1 >> 1;
    EXPECT_EQ("10000000000000000000000000000000000000000000000000000000000000000", get_str(genome1));
    EXPECT_EQ("01000000000000000000000000000000000000000000000000000000000000000", get_str(genome2));
}

TEST(genome_and, test_one)
{
    array<gint, 1> data1 = {0b0011};
    array<gint, 1> data2 = {0b0101};
    Genome<4> genome1(data1);
    Genome<4> genome2(data2);
    genome1 &= genome2;
    EXPECT_EQ("0001", get_str(genome1));
}

TEST(genome_and, test_two)
{
    array<gint, 2> data1 = {0b0011, 0b0011};
    array<gint, 2> data2 = {0b0101, 0b0101};
    Genome<68> genome1(data1);
    Genome<68> genome2(data2);
    genome1 &= genome2;
    EXPECT_EQ("00010000000000000000000000000000000000000000000000000000000000000001", get_str(genome1));
}

TEST(genome_and, unassigned)
{
    array<gint, 1> data1 = {0b0011};
    array<gint, 1> data2 = {0b0101};
    Genome<4> genome1(data1);
    Genome<4> genome2(data2);
    Genome<4> genome3 = genome1 & genome2;
    EXPECT_EQ("0011", get_str(genome1));
    EXPECT_EQ("0101", get_str(genome2));
    EXPECT_EQ("0001", get_str(genome3));
}

TEST(genome_or, test_one)
{
    array<gint, 1> data1 = {0b0011};
    array<gint, 1> data2 = {0b0101};
    Genome<4> genome1(data1);
    Genome<4> genome2(data2);
    genome1 |= genome2;
    EXPECT_EQ("0111", get_str(genome1));
}

TEST(genome_or, test_two)
{
    array<gint, 2> data1 = {0b0011, 0b0011};
    array<gint, 2> data2 = {0b0101, 0b0101};
    Genome<68> genome1(data1);
    Genome<68> genome2(data2);
    genome1 |= genome2;
    EXPECT_EQ("01110000000000000000000000000000000000000000000000000000000000000111", get_str(genome1));
}

TEST(genome_or, unassigned)
{
    array<gint, 1> data1 = {0b0011};
    array<gint, 1> data2 = {0b0101};
    Genome<4> genome1(data1);
    Genome<4> genome2(data2);
    Genome<4> genome3 = genome1 | genome2;
    EXPECT_EQ("0011", get_str(genome1));
    EXPECT_EQ("0101", get_str(genome2));
    EXPECT_EQ("0111", get_str(genome3));
}

TEST(genome_xor, test_one)
{
    array<gint, 1> data1 = {0b0011};
    array<gint, 1> data2 = {0b0101};
    Genome<4> genome1(data1);
    Genome<4> genome2(data2);
    genome1 ^= genome2;
    EXPECT_EQ("0110", get_str(genome1));
}

TEST(genome_xor, test_two)
{
    array<gint, 2> data1 = {0b0011, 0b0011};
    array<gint, 2> data2 = {0b0101, 0b0101};
    Genome<68> genome1(data1);
    Genome<68> genome2(data2);
    genome1 ^= genome2;
    EXPECT_EQ("01100000000000000000000000000000000000000000000000000000000000000110", get_str(genome1));
}

TEST(genome_xor, unassigned)
{
    array<gint, 1> data1 = {0b0011};
    array<gint, 1> data2 = {0b0101};
    Genome<4> genome1(data1);
    Genome<4> genome2(data2);
    Genome<4> genome3 = genome1 ^ genome2;
    EXPECT_EQ("0011", get_str(genome1));
    EXPECT_EQ("0101", get_str(genome2));
    EXPECT_EQ("0110", get_str(genome3));
}

TEST(genome_not, test_one)
{
    array<gint, 1> data = {0b0011};
    Genome<4> genome(data);
    genome.complement();
    EXPECT_EQ("1100", get_str(genome));
}

TEST(genome_not, test_two)
{
    array<gint, 2> data = {0b0011, 0b011};
    Genome<68> genome(data);
    genome.complement();
    EXPECT_EQ("11001111111111111111111111111111111111111111111111111111111111111100", get_str(genome));
}

TEST(genome_rotl, test_shifted_perfect)
{
    array<gint, 1> data = {0b0011};
    Genome<64> genome(data);
    genome.rotl(2);
    EXPECT_EQ("0000000000000000000000000000000000000000000000000000000000001100", get_str(genome));
}

TEST(genome_rotl, test_rotated_perfect)
{
    array<gint, 1> data = {
        0b1100000000000000000000000000000000000000000000000000000000000011};
    Genome<64> genome(data);
    genome.rotl(2);
    EXPECT_EQ("0000000000000000000000000000000000000000000000000000000000001111", get_str(genome));
}

TEST(genome_rotl, test_rotated_imperfect)
{
    array<gint, 1> data = {
        0b1001};
    Genome<4> genome(data);
    genome.rotl(1);
    EXPECT_EQ("0011", get_str(genome));
}

TEST(genome_rotr, test_shifted_perfect)
{
    array<gint, 1> data = {0b1100};
    Genome<64> genome(data);
    genome.rotr(2);
    EXPECT_EQ("0000000000000000000000000000000000000000000000000000000000000011", get_str(genome));
}

TEST(genome_rotr, test_rotated_perfect)
{
    array<gint, 1> data = {
        0b1100000000000000000000000000000000000000000000000000000000000011};
    Genome<64> genome(data);
    genome.rotr(2);
    EXPECT_EQ("1111000000000000000000000000000000000000000000000000000000000000", get_str(genome));
}

TEST(genome_rotr, test_rotated_imperfect)
{
    array<gint, 1> data = {
        0b1001};
    Genome<4> genome(data);
    genome.rotr(1);
    EXPECT_EQ("1100", get_str(genome));
}

TEST(genome_popcount, test_small)
{
    array<gint, 1> data = {
        0b1001};
    Genome<4> genome(data);
    EXPECT_EQ(2, genome.popcount());
}

TEST(genome_popcount, test_large)
{
    array<gint, 1> data = {
        0b0000000100000001000000010000000100000001000000010000000100000001};
    Genome<64> genome(data);
    EXPECT_EQ(8, genome.popcount());
}

TEST(genome_parity, test_small_negative)
{
    array<gint, 1> data = {
        0b1100000000000000000000000000000000000000000000000000000000001001};
    Genome<64> genome(data);
    EXPECT_EQ(0, genome.parity());
}

TEST(genome_parity, test_small_positive)
{
    array<gint, 1> data = {
        0b1100000000000000000000000000100000000000000000000000000000001001};
    Genome<64> genome(data);
    EXPECT_EQ(1, genome.parity());
}

TEST(genome_parity, test_large_negative)
{
    array<gint, 2> data = {
        0b1100000000000000000000000000010000000000000000000000000000001001, 
        0b1};
    Genome<65> genome(data);
    EXPECT_EQ(0, genome.parity());
}

TEST(genome_parity, test_large_positive)
{
    array<gint, 2> data = {
        0b1100000000000000000000000010010000000000000000000000000000001001, 
        0b1};
    Genome<65> genome(data);
    EXPECT_EQ(1, genome.parity());
}

TEST(genome_reverse, test_single)
{
    array<gint, 1> data = {
        0b0000000000000000000000000000000101010101010101010101010101010111
        };
    Genome<64> genome(data);
    genome.reverse();
    EXPECT_EQ("1110101010101010101010101010101010000000000000000000000000000000", get_str(genome));
}

TEST(genome_reverse, test_double)
{
    array<gint, 2> data = {
        0b0000000000000000000000000000000101010101010101010101010101010111,
        0b0000000000000000000000000000000110011001100110011001100110011001
        };
    Genome<2*64> genome(data);
    genome.reverse();
    EXPECT_EQ("11101010101010101010101010101010100000000000000000000000000000001001100110011001100110011001100110000000000000000000000000000000", get_str(genome));
}

TEST(genome_reverse, test_triple)
{
    array<gint, 3> data = {
        0b0000000000000000000000000000000101010101010101010101010101010111,
        0b0000000000000000000000000000000110011001100110011001100110011001,
        0b0000000000000000000000000000000111000111000111000111000111000111
        };
    Genome<3*64> genome(data);
    genome.reverse();
    EXPECT_EQ("111010101010101010101010101010101000000000000000000000000000000010011001100110011001100110011001100000000000000000000000000000001110001110001110001110001110001110000000000000000000000000000000", get_str(genome));
}

TEST(genome_reverse, test_imperfect)
{
    array<gint, 1> data = {
        0b0010
        };
    Genome<4> genome(data);
    genome.reverse();
    EXPECT_EQ("0100", get_str(genome));
}

TEST(genome_reverse, test_long_imperfect)
{
    array<gint, 4> data = {
        0b0000000000000000000000000000000101010101010101010101010101010111,
        0b0000000000000000000000000000000110011001100110011001100110011001,
        0b0000000000000000000000000000000111000111000111000111000111000111,
        0b0010
        };
    Genome<3*64+4> genome(data);
    genome.reverse();
    EXPECT_EQ("1110101010101010101010101010101010000000000000000000000000000000100110011001100110011001100110011000000000000000000000000000000011100011100011100011100011100011100000000000000000000000000000000100", get_str(genome));
}

TEST(genome_reverse, test_imperfect_prime)
{
    array<gint, 1> data = {
        0b0000010
        };
    Genome<7> genome(data);
    genome.reverse();
    EXPECT_EQ("0100000", get_str(genome));
}

TEST(delete_me, test_imperfect_prime)
{
    array<gint, 2> dthree = {7, 0};
    Genome<120> three(dthree);
    array<gint, 2> dfour = {15, 0};
    Genome<120> four(dfour);
    array<gint, 2> dfive = {31, 0};
    Genome<120> five(dfive);
    Genome<120> threes;
    Genome<120> fours;
    Genome<120> fives;
    for(int i = 0; i < 120; i++)
    {
        threes = ((threes << 3*2) | three);
        fours = ((fours << 4*2) | four);
        fives = ((fives << 5*2) | five);
    }
    Genome<120> comp_three = three;
    comp_three.complement();
    threes = threes & fours & fives & comp_three;
    cout << threes << endl;
}

}
