#include <iostream>
#include <cmath>
#include <array>

/*
For a HCN_k:
Maximise sum (1+a_m) for m in (1, k)
That gives the smallest prod p^a_m for m in (1, k) 

Lemma: each cardinality of divisors has exactly 1 HCN_k

2    -                        - 1           - 2
4    - 2, 2                   - 2           - 3
6    - 2, 3                   - 1, 1        - 4
12   - 2, 2, 3                - 2, 1        - 6
24   - 2, 2, 2, 3             - 3, 1        - 8
36   - 2, 2, 3, 3             - 2, 2        - 9
48   - 2, 2, 2, 2, 3          - 4, 1        - 10
60   - 2, 2, 3, 5             - 2, 1, 1     - 12
120  - 2, 2, 2, 3, 5          - 3, 1, 1     - 16
180  - 2, 2, 3, 3, 5          - 2, 2, 1     - 18
240  - 2, 2, 2, 2, 3, 5       - 4, 1, 1     - 20
360  - 2, 2, 2, 3, 3, 5       - 3, 2, 1     - 24
720  - 2, 2, 2, 2, 3, 3, 5    - 4, 2, 1     - 30
840  - 2, 2, 2, 3, 5, 7       - 3, 1, 1, 1  - 32
1260 - 2, 2, 3, 3, 5, 7       - 2, 2, 1, 1  - 36
1680 - 2, 2, 2, 2, 3, 5, 7    - 4, 1, 1, 1  - 40
2520 - 2, 2, 2, 3, 3, 5, 7    - 3, 2, 1, 1  - 48
5040 - 2, 2, 2, 2, 3, 3, 5, 7 - 4, 2, 1, 1  - 60
*/

typedef std::array<unsigned int, 20> a_type;

unsigned int divisors(a_type a) {
    unsigned int total = 1;
    for(auto a_m : a) {
        total *= 1 + a_m;
    }
    return total;
}

unsigned long long getHCN(a_type a) {
    unsigned long long hcn = 1;
    for(auto a_m : a)
        ;
}

int main() {
    unsigned long long v = 1;
    std::array<int, 20> a{0};


}
