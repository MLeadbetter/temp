-- exercises.hs

module Exercises where

squat = [1,2,1,2,2,1,0,0,2,0,0,0,0,0]
legPress = [1,2,1,2,0,0,0,0,0,0,0,0,0,0]
lunge = [0,2,2,2,2,0,0,0,0,0,0,0,0,0]
deadlift = [1,2,2,2,2,2,0,1,1,0,0,0,0,1]
legExtension = [0,2,0,0,0,0,0,0,0,0,0,0,0,0]
legCurl = [1,0,2,0,0,0,0,0,0,0,0,0,0,0]
standingCalfRaise = [2,0,0,0,0,0,0,0,0,0,0,0,0,0]
seatedCalfRaise = [2,0,0,0,0,0,0,0,0,0,0,0,0,0]
hipAdductor = [0,0,0,0,2,0,0,0,0,0,0,0,0,0]
benchPress = [0,0,0,0,0,0,0,0,0,2,1,2,0,0]
chestFly = [0,0,0,0,0,0,0,0,0,2,1,0,0,0]
pushUp = [0,0,0,0,0,0,0,0,1,2,1,2,0,0]
pullDown = [0,0,0,0,0,0,2,0,0,1,1,0,1,1]
pullUp = [0,0,0,0,0,0,2,1,0,1,1,0,1,1]
bentoverRow = [0,0,0,0,0,0,2,1,0,0,0,0,1,1]
uprightRow = [0,0,0,0,0,0,0,2,0,0,2,0,1,1]
shoulderPress = [0,0,0,0,0,0,0,1,0,0,2,1,0,0]
shoulderFly = [0,0,0,0,0,0,0,1,0,0,2,0,0,1]
lateralRaise = [0,0,0,0,0,0,0,1,0,0,2,0,0,0]
shoulderShrug = [0,0,0,0,0,0,0,2,0,0,1,0,0,1]
pushdown = [0,0,0,0,0,0,0,0,0,0,0,2,0,0]
tricepsExtension = [0,0,0,0,0,0,0,0,0,0,0,2,0,1]
bicepsCurl = [0,0,0,0,0,0,0,0,0,0,0,0,2,1]
crunch = [0,0,0,0,0,0,0,0,2,0,0,0,0,0]
russianTwist = [0,0,0,0,0,0,0,0,2,0,0,0,0,0]
legRaise = [0,0,0,0,2,0,0,0,1,0,0,0,0,0]
backExtension = [0,0,1,2,0,2,0,0,0,0,0,0,0,0]

exercises = [squat,
             legPress,
             lunge,
             deadlift,
             legExtension,
             legCurl,
             standingCalfRaise,
             seatedCalfRaise,
             hipAdductor,
             benchPress,
             chestFly,
             pushUp,
             pullDown,
             pullUp,
             bentoverRow,
             uprightRow,
             shoulderPress,
             shoulderFly,
             lateralRaise,
             shoulderShrug,
             pushdown,
             tricepsExtension,
             bicepsCurl,
             crunch,
             russianTwist,
             legRaise,
             backExtension]

previousDay choices day = if day > 0 then choices !! (day-1) else []
-- validOnDay choices day = 
